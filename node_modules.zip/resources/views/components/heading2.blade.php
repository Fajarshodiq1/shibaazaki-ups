<h2 {{ $attributes->merge(['class' => 'text-2xl sm:text-3xl font-semibold text-gray-800']) }}>
    {{ $slot }}
</h2>
