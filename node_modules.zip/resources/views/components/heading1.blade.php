<h1 {{ $attributes->merge(['class' => 'font-semibold text-2xl sm:text-[32px] lg:mb-1 text-center lg:text-start']) }}>
    {{ $slot }}
</h1>
