
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('title', 'Profil - Shibaazaki'); ?>
<header
    class="w-full pt-[74px] pb-[34px] bg-[url('https://images.pexels.com/photos/8071904/pexels-photo-8071904.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')] bg-cover bg-no-repeat bg-center relative z-0">
    <div class="container max-w-[1130px] mx-auto flex flex-col items-center justify-center gap-[34px] z-10">
        <div class="flex flex-col gap-2 text-center w-fit mt-20 z-10">
            <h1 class="font-semibold text-2xl lg:text-[60px] leading-[130%]">Profile Kami</h1>
        </div>
    </div>
    <div class="w-full h-full absolute top-0 bg-gradient-to-b from-belibang-black/70 to-belibang-black z-0"></div>
</header>
<section class="container max-w-[1230px] mx-auto mb-16 flex flex-col gap-8 px-4 sm:px-6 lg:px-8 mt-10">
    <div class="grid lg:grid-cols-2 gap-10 items-center">
        <!-- Text Content -->
        <div class="space-y-6">
            <h2 class="font-semibold text-2xl sm:text-3xl lg:text-4xl mb-3 lg:mb-5 leading-snug">
                UPS Shibaazaki
            </h2>
            <div class="prose prose-sm sm:prose-base lg:prose-lg text-belibang-grey leading-relaxed max-w-none">
                <p>
                    Kami merupakan penyedia jasa Rental UPS, Sewa UPS, dan juga melayani Maintenance UPS. Kami berlokasi
                    di Jakarta tepatnya di Jl. Mawar No 42 RT006/Rw08 Srengseng, Kec. Kembangan, Kota Jakarta Barat
                    11630. Kami telah berpengalaman dalam menangani Service, Installasi & Maintenance berbagai merk UPS
                    seperti : APC, Chloride, Bauma, Delta Power, ICA, Laplace, Emerson, Liebert, MGE, Sendon, Toshiba,
                    Powerware, Pascal, Unipower, Vektor dll. UPS Subrata dapat melayani jasa Rental UPS maupun service
                    UPS mencakup daerah JABODETABEK hingga seluruh Indonesia.
                </p>
                <p>
                    Selain melayani jasa rental UPS kami juga melayani penjualan UPS baru, UPS Second dan menjual
                    Battery. Kami telah berkomitmen untuk selalu menyediakan produk-produk elektrik yang berkualitas
                    tinggi dan memberikan pelayanan terbaik tentunya dengan harga terjangkau dan bersaing.
                </p>
            </div>
            <div class="flex flex-wrap gap-3">
                <a href="about.html"
                    class="px-5 py-2.5 sm:px-6 sm:py-3 bg-gradient-to-r w-fit from-blue-500 to-green-500 text-white rounded-full hover:from-blue-600 hover:to-green-600 transition-all duration-300 flex items-center gap-2 text-sm sm:text-base">
                    Selengkapnya
                </a>
                <a href="about.html"
                    class="px-5 py-2.5 sm:px-6 sm:py-3 border rounded-full transition-all duration-300 flex items-center gap-2 text-sm sm:text-base">
                    Hubungi Kami
                </a>
            </div>
        </div>

        <!-- Image Content -->
        <div class="relative">
            <div class="p-[1px] rounded-2xl bg-img-purple-to-orange">
                <div
                    class="bg-img-black-gradient rounded-2xl p-4 sm:p-6 lg:p-8 h-[250px] sm:h-[350px] lg:h-[500px] flex items-center justify-center">
                    <img src="https://scontent.fcgk24-2.fna.fbcdn.net/v/t39.30808-6/475301182_496416920170422_7602111244084816273_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=127cfc&_nc_eui2=AeEvOoo5WowSJWshj6geSxwhIFlJ652DcKwgWUnrnYNwrJx3_-5wDtmftJ1WuVLOsN3TIreCoxHqNxRs5OoBTLkc&_nc_ohc=dwkrzTcLTzoQ7kNvwGeh3VS&_nc_oc=AdkES85hIcwqxP1hxqRahrXYui9NQDGecmggHYMYNfMdVX7nrsVp5qPVOrH5hUegc0A&_nc_zt=23&_nc_ht=scontent.fcgk24-2.fna&_nc_gid=XYZkKOtqKu-xtC8nLyvAyg&oh=00_AfVbqgNbuooBhcf1SVoZAFCPf8S2Qn975gRZSeSJHGB5tA&oe=68AA5D90"
                        alt="UPS Shibaazaki" class="w-full h-full object-cover rounded-2xl">
                </div>
            </div>
        </div>
    </div>
</section>

<section class="container max-w-[1230px] mx-auto mb-[102px] flex flex-col gap-8 px-4 sm:px-6 lg:px-8">
    <h2 class="font-semibold text-xl md:text-2xl lg:text-3xl sm:text-4xl mb-5 text-white text-center">Keunggulan UPS
        <br>Shibaazaki👏
    </h2>
    <div class="grid sm:grid-cols-2 lg:grid-cols-4 gap-8">
        <!-- Card 1: Pelayanan Terbaik -->
        <div
            class="stat-card p-[1px] rounded-2xl bg-transparent hover:bg-gradient-to-r hover:from-green-500 hover:to-blue-500 transition-all duration-300">
            <div class="bg-belibang-darker-grey rounded-2xl p-8 text-center h-full transition-all duration-300">
                <div class="w-16 h-16 mx-auto mb-4 bg-blue-500 rounded-full flex items-center justify-center">
                    <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z">
                        </path>
                    </svg>
                </div>
                <div class="text-xl font-bold text-blue-400 mb-2">Pelayanan Terbaik</div>
                <p class="text-gray-400 text-sm">Layanan 24/7 dengan respon cepat dan solusi tepat sasaran</p>
            </div>
        </div>

        <!-- Card 2: Hasil Memuaskan -->
        <div
            class="stat-card p-[1px] rounded-2xl bg-transparent hover:bg-gradient-to-r hover:from-green-500 hover:to-blue-500 transition-all duration-300">
            <div class="bg-belibang-darker-grey rounded-2xl p-8 text-center h-full transition-all duration-300">
                <div class="w-16 h-16 mx-auto mb-4 bg-green-500 rounded-full flex items-center justify-center">
                    <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path>
                    </svg>
                </div>
                <div class="text-xl font-bold text-green-400 mb-2">Hasil Memuaskan</div>
                <p class="text-gray-400 text-sm">Kualitas kerja terjamin dengan tingkat kepuasan pelanggan tinggi
                </p>
            </div>
        </div>

        <!-- Card 3: Tim Profesional -->
        <div
            class="stat-card p-[1px] rounded-2xl bg-transparent hover:bg-gradient-to-r hover:from-green-500 hover:to-blue-500 transition-all duration-300">
            <div class="bg-belibang-darker-grey rounded-2xl p-8 text-center h-full transition-all duration-300">
                <div class="w-16 h-16 mx-auto mb-4 bg-purple-500 rounded-full flex items-center justify-center">
                    <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z">
                        </path>
                    </svg>
                </div>
                <div class="text-xl font-bold text-purple-400 mb-2">Tim Profesional</div>
                <p class="text-gray-400 text-sm">Teknisi berpengalaman dan bersertifikat internasional</p>
            </div>
        </div>

        <!-- Card 4: Garansi Panjang -->
        <div
            class="stat-card p-[1px] rounded-2xl bg-transparent hover:bg-gradient-to-r hover:from-green-500 hover:to-blue-500 transition-all duration-300">
            <div class="bg-belibang-darker-grey rounded-2xl p-8 text-center h-full transition-all duration-300">
                <div class="w-16 h-16 mx-auto mb-4 bg-orange-500 rounded-full flex items-center justify-center">
                    <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z">
                        </path>
                    </svg>
                </div>
                <div class="text-xl font-bold text-orange-400 mb-2">Garansi Panjang</div>
                <p class="text-gray-400 text-sm">Garansi hingga 2 tahun dengan after-sales service terpercaya</p>
            </div>
        </div>
    </div>
</section>
<section class="container max-w-[1230px] mx-auto mb-[102px] px-4 sm:px-6 lg:px-8">
    <!-- Header -->
    <div class="text-center mb-16">
        <h2 class="font-semibold text-xl md:text-3xl lg:text-4xl mb-5 text-white">
            Klien Kami 🤝
        </h2>
        <p class="text-gray-300 text-sm md:text-base lg:text-lg max-w-2xl mx-auto mb-8">
            Dipercaya oleh berbagai perusahaan terkemuka untuk kebutuhan UPS dan backup power mereka
        </p>
        <div class="flex items-center justify-center gap-8 text-sm text-gray-400">
            <div class="flex items-center gap-2">
                <span class="w-2 h-2 bg-green-500 rounded-full"></span>
                <span>500+ Klien Aktif</span>
            </div>
            <div class="flex items-center gap-2">
                <span class="w-2 h-2 bg-blue-500 rounded-full"></span>
                <span>10+ Tahun Pengalaman</span>
            </div>
            <div class="flex items-center gap-2">
                <span class="w-2 h-2 bg-purple-500 rounded-full"></span>
                <span>100% Kepuasan</span>
            </div>
        </div>
    </div>

    <!-- Logo Slider -->
    <div class="overflow-hidden mb-16 bg-belibang-darker-grey rounded-2xl p-4 sm:p-6 lg:p-8">
        <div class="scrolling-wrapper flex items-center" style="width: 200%;">
            <!-- Set 1 -->
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://img.lazcdn.com/g/p/a1eeec26b4ee0b9ce69dfe7a57dc3e93.jpg_720x720q80.jpg"
                    alt="Client Logo" loading="lazy">
            </div>
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Bank_Mandiri_logo_2016.svg/1200px-Bank_Mandiri_logo_2016.svg.png"
                    alt="Bank Mandiri" loading="lazy">
            </div>
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://upload.wikimedia.org/wikipedia/id/thumb/5/55/BNI_logo.svg/1024px-BNI_logo.svg.png"
                    alt="Bank BNI" loading="lazy">
            </div>
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://jobtrenurtika.wordpress.com/wp-content/uploads/2015/07/logo-telkom-indonesia-transparent-background.png"
                    alt="Telkom Indonesia" loading="lazy">
            </div>
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://mpp.badungkab.go.id/images/agency/logo/pln.png" alt="PLN" loading="lazy">
            </div>
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Bank_Central_Asia.svg/2560px-Bank_Central_Asia.svg.png"
                    alt="Bank BCA" loading="lazy">
            </div>
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://buatlogoonline.com/wp-content/uploads/2022/10/Logo-Bank-BRI.png" alt="Bank BRI"
                    loading="lazy">
            </div>
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/Indosat_Ooredoo.svg/2560px-Indosat_Ooredoo.svg.png"
                    alt="Indosat Ooredoo" loading="lazy">
            </div>

            <!-- Set 2 (duplicate untuk seamless loop) -->
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://img.lazcdn.com/g/p/a1eeec26b4ee0b9ce69dfe7a57dc3e93.jpg_720x720q80.jpg"
                    alt="Client Logo" loading="lazy">
            </div>
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ad/Bank_Mandiri_logo_2016.svg/1200px-Bank_Mandiri_logo_2016.svg.png"
                    alt="Bank Mandiri" loading="lazy">
            </div>
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://upload.wikimedia.org/wikipedia/id/thumb/5/55/BNI_logo.svg/1024px-BNI_logo.svg.png"
                    alt="Bank BNI" loading="lazy">
            </div>
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://jobtrenurtika.wordpress.com/wp-content/uploads/2015/07/logo-telkom-indonesia-transparent-background.png"
                    alt="Telkom Indonesia" loading="lazy">
            </div>
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://mpp.badungkab.go.id/images/agency/logo/pln.png" alt="PLN" loading="lazy">
            </div>
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/5/5c/Bank_Central_Asia.svg/2560px-Bank_Central_Asia.svg.png"
                    alt="Bank BCA" loading="lazy">
            </div>
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://buatlogoonline.com/wp-content/uploads/2022/10/Logo-Bank-BRI.png" alt="Bank BRI"
                    loading="lazy">
            </div>
            <div
                class="client-logo bg-white rounded-full p-2 sm:p-3 lg:p-4 w-12 h-12 sm:w-16 sm:h-16 lg:w-20 lg:h-20 flex items-center justify-center">
                <img src="https://upload.wikimedia.org/wikipedia/commons/thumb/1/12/Indosat_Ooredoo.svg/2560px-Indosat_Ooredoo.svg.png"
                    alt="Indosat Ooredoo" loading="lazy">
            </div>
        </div>
    </div>

    <!-- Client Cards -->
    <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
        <!-- Card 1: Perbankan -->
        <div
            class="client-card bg-belibang-darker-grey rounded-2xl p-8 hover:transform hover:scale-105 transition-all duration-300">
            <div class="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center mb-6">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z">
                    </path>
                </svg>
            </div>
            <h3 class="text-xl font-bold text-white mb-3">Sektor Perbankan</h3>
            <p class="text-gray-300 text-sm mb-4">Melayani berbagai bank terkemuka dengan sistem UPS yang handal untuk
                menjaga kontinuitas operasional perbankan.</p>
            <div class="text-sm text-gray-400">
                <span class="font-semibold text-green-400">15+</span> Bank Partner
            </div>
        </div>

        <!-- Card 2: Telekomunikasi -->
        <div
            class="client-card bg-belibang-darker-grey rounded-2xl p-8 hover:transform hover:scale-105 transition-all duration-300">
            <div class="w-16 h-16 bg-blue-500 rounded-full flex items-center justify-center mb-6">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M8.111 16.404a5.5 5.5 0 017.778 0M12 20h.01m-7.08-7.071c3.904-3.905 10.236-3.905 14.141 0M1.394 9.393c5.857-5.857 15.355-5.857 21.213 0">
                    </path>
                </svg>
            </div>
            <h3 class="text-xl font-bold text-white mb-3">Telekomunikasi</h3>
            <p class="text-gray-300 text-sm mb-4">Menjaga jaringan telekomunikasi tetap aktif 24/7 dengan solusi UPS
                terdepan untuk provider terkemuka.</p>
            <div class="text-sm text-gray-400">
                <span class="font-semibold text-blue-400">8+</span> Provider Telco
            </div>
        </div>

        <!-- Card 3: BUMN -->
        <div
            class="client-card bg-belibang-darker-grey rounded-2xl p-8 hover:transform hover:scale-105 transition-all duration-300">
            <div class="w-16 h-16 bg-red-500 rounded-full flex items-center justify-center mb-6">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4">
                    </path>
                </svg>
            </div>
            <h3 class="text-xl font-bold text-white mb-3">BUMN</h3>
            <p class="text-gray-300 text-sm mb-4">Mendukung operasional BUMN dengan sistem backup power yang reliable
                untuk infrastruktur kritis negara.</p>
            <div class="text-sm text-gray-400">
                <span class="font-semibold text-red-400">12+</span> Perusahaan BUMN
            </div>
        </div>

        <!-- Card 4: Rumah Sakit -->
        <div
            class="client-card bg-belibang-darker-grey rounded-2xl p-8 hover:transform hover:scale-105 transition-all duration-300">
            <div class="w-16 h-16 bg-pink-500 rounded-full flex items-center justify-center mb-6">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z">
                    </path>
                </svg>
            </div>
            <h3 class="text-xl font-bold text-white mb-3">Rumah Sakit</h3>
            <p class="text-gray-300 text-sm mb-4">Menjamin keamanan pasien dengan sistem UPS medis grade yang tidak
                boleh gagal dalam situasi darurat.</p>
            <div class="text-sm text-gray-400">
                <span class="font-semibold text-pink-400">25+</span> Rumah Sakit
            </div>
        </div>

        <!-- Card 5: Data Center -->
        <div
            class="client-card bg-belibang-darker-grey rounded-2xl p-8 hover:transform hover:scale-105 transition-all duration-300">
            <div class="w-16 h-16 bg-purple-500 rounded-full flex items-center justify-center mb-6">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01">
                    </path>
                </svg>
            </div>
            <h3 class="text-xl font-bold text-white mb-3">Data Center</h3>
            <p class="text-gray-300 text-sm mb-4">Melindungi infrastruktur IT kritikal dengan sistem UPS enterprise
                untuk uptime maksimal data center.</p>
            <div class="text-sm text-gray-400">
                <span class="font-semibold text-purple-400">20+</span> Data Center
            </div>
        </div>

        <!-- Card 6: Manufaktur -->
        <div
            class="client-card bg-belibang-darker-grey rounded-2xl p-8 hover:transform hover:scale-105 transition-all duration-300">
            <div class="w-16 h-16 bg-yellow-500 rounded-full flex items-center justify-center mb-6">
                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z">
                    </path>
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path>
                </svg>
            </div>
            <h3 class="text-xl font-bold text-white mb-3">Manufaktur</h3>
            <p class="text-gray-300 text-sm mb-4">Mendukung kelancaran produksi dengan sistem UPS industrial yang tahan
                terhadap kondisi ekstrem.</p>
            <div class="text-sm text-gray-400">
                <span class="font-semibold text-yellow-400">30+</span> Pabrik
            </div>
        </div>
    </div>

    
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\CODING\shibaazaki-website\resources\views/front/pages/profile.blade.php ENDPATH**/ ?>