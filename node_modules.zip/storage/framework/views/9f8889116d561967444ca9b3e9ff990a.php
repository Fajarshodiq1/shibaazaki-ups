<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'name',
    'id' => null,
    'value' => '',
    'label' => null,
    'optional' => false,
    'limit' => false,
    'placeholder' => 'Write something...',
    'height' => 300,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'name',
    'id' => null,
    'value' => '',
    'label' => null,
    'optional' => false,
    'limit' => false,
    'placeholder' => 'Write something...',
    'height' => 300,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="space-y-2">
    
    <?php if($label): ?>
        <div class="flex items-center space-x-2">
            <i class="fas fa-align-left text-indigo-500"></i>
            <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => ''.e($name).'','value' => $label,'class' => 'text-base font-medium']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => ''.e($name).'','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($label),'class' => 'text-base font-medium']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
            <?php if($optional): ?>
                <span class="text-gray-400 text-sm">(Optional)</span>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    
    <div class="ckeditor-wrapper">
        <div
            class="bg-white border-2 border-gray-200 rounded-lg focus-within:border-indigo-500 focus-within:ring-2 focus-within:ring-indigo-200 transition-all duration-200">
            <textarea id="<?php echo e($id ?? $name); ?>" name="<?php echo e($name); ?>" class="ckeditor-textarea" placeholder="<?php echo e($placeholder); ?>"><?php echo e(old($name, $value)); ?></textarea>
        </div>
    </div>

    
    <div class="flex justify-between items-center">
        <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get($name)]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get($name))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
        <?php if($limit): ?>
            <span class="text-xs text-gray-400" id="charCount-<?php echo e($id ?? $name); ?>">0/<?php echo e($limit); ?>

                characters</span>
        <?php endif; ?>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script defer>
        document.addEventListener('DOMContentLoaded', function() {
            const editorId = "<?php echo e($id ?? $name); ?>";
            const charCountId = "charCount-<?php echo e($id ?? $name); ?>";
            const limit = <?php echo e($limit ?: 'null'); ?>;
            const height = <?php echo e($height); ?>;

            ClassicEditor
                .create(document.querySelector(`#${editorId}`), {
                    placeholder: <?php echo json_encode($placeholder, 15, 512) ?>,
                    toolbar: {
                        items: [
                            'heading',
                            '|',
                            'bold',
                            'italic',
                            'underline',
                            'strikethrough',
                            '|',
                            'fontColor',
                            'fontBackgroundColor',
                            '|',
                            'numberedList',
                            'bulletedList',
                            'outdent',
                            'indent',
                            '|',
                            'alignment',
                            '|',
                            'link',
                            'insertTable',
                            'blockQuote',
                            '|',
                            'undo',
                            'redo',
                            'removeFormat'
                        ]
                    },
                    heading: {
                        options: [{
                                model: 'paragraph',
                                title: 'Paragraph',
                                class: 'ck-heading_paragraph'
                            },
                            {
                                model: 'heading1',
                                view: 'h1',
                                title: 'Heading 1',
                                class: 'ck-heading_heading1'
                            },
                            {
                                model: 'heading2',
                                view: 'h2',
                                title: 'Heading 2',
                                class: 'ck-heading_heading2'
                            },
                            {
                                model: 'heading3',
                                view: 'h3',
                                title: 'Heading 3',
                                class: 'ck-heading_heading3'
                            }
                        ]
                    },
                    table: {
                        contentToolbar: ['tableColumn', 'tableRow', 'mergeTableCells']
                    }
                })
                .then(editor => {
                    // Set editor height
                    editor.editing.view.change(writer => {
                        writer.setStyle('min-height', `${height}px`, editor.editing.view.document
                            .getRoot());
                    });

                    // Character limit and counter functionality
                    if (limit) {
                        const charCountEl = document.getElementById(charCountId);

                        function updateCharCount() {
                            const text = editor.getData().replace(/<[^>]*>/g, ''); // Strip HTML tags
                            const count = text.trim().length;

                            if (charCountEl) {
                                charCountEl.textContent = `${count}/${limit} characters`;
                                charCountEl.style.color = count > limit ? '#ef4444' : '#9ca3af';
                            }

                            // Prevent exceeding limit
                            if (count > limit) {
                                const currentData = editor.getData();
                                const truncatedText = text.substring(0, limit);
                                // This is a simple truncation - you might want more sophisticated handling
                                editor.setData(currentData.substring(0, currentData.length - (count - limit)));
                            }
                        }

                        // Update count on content change
                        editor.model.document.on('change:data', updateCharCount);

                        // Initial count
                        updateCharCount();
                    }

                    // Handle form submission
                    const form = document.querySelector(`#${editorId}`).closest('form');
                    if (form) {
                        form.addEventListener('submit', function() {
                            // CKEditor automatically updates the textarea value
                            // No additional action needed
                        });
                    }
                })
                .catch(error => {
                    console.error('CKEditor initialization error:', error);
                });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .ckeditor-wrapper .ck-editor__editable {
            border-radius: 0 0 0.5rem 0.5rem;
        }

        .ckeditor-wrapper .ck-toolbar {
            border-radius: 0.5rem 0.5rem 0 0;
            border-color: #e5e7eb;
        }

        .ckeditor-wrapper .ck-editor__editable_inline {
            border-color: #e5e7eb;
        }

        .ckeditor-wrapper:focus-within .ck-toolbar,
        .ckeditor-wrapper:focus-within .ck-editor__editable_inline {
            border-color: #6366f1 !important;
        }

        .ckeditor-wrapper .ck-content {
            font-size: 14px;
        }

        /* Hide the original textarea */
        .ckeditor-textarea {
            display: none;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\CODING\shibaazaki-website\resources\views/components/quill-editor.blade.php ENDPATH**/ ?>