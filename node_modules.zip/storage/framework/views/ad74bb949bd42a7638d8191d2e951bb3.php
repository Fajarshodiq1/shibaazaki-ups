<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['disabled' => false, 'label' => null, 'icon' => null, 'type' => 'text']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['disabled' => false, 'label' => null, 'icon' => null, 'type' => 'text']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="w-full">
    
    <?php if($label): ?>
        <label class="block mb-2 text-sm font-medium text-gray-700">
            <?php echo e($label); ?>

        </label>
    <?php endif; ?>

    <div class="relative">
        
        <?php if($icon): ?>
            <span class="absolute inset-y-0 left-0 flex items-center pl-3 text-gray-400">
                <?php echo $icon; ?>

            </span>
        <?php endif; ?>

        <input type="<?php echo e($type); ?>" <?php if($disabled): echo 'disabled'; endif; ?>
            <?php echo e($attributes->merge([
                'class' =>
                    'w-full rounded-xl border border-gray-200 bg-white shadow-sm
                                focus:border-indigo-400 focus:ring focus:ring-indigo-300 focus:ring-opacity-40
                                placeholder-gray-400 text-gray-700 text-sm 
                                px-4 py-3 ' .
                    ($icon ? 'pl-10' : '') .
                    ' transition ease-in-out duration-200',
            ])); ?>>
    </div>
</div>
<?php /**PATH C:\Users\fajar\Downloads\shibaazaki\vendor\resources\views/components/text-input.blade.php ENDPATH**/ ?>