<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['type' => 'submit']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['type' => 'submit']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<button type="<?php echo e($type); ?>"
    <?php echo e($attributes->merge([
        'class' => 'inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 
                        hover:from-blue-700 hover:to-blue-800 text-white font-semibold rounded-lg 
                        shadow-lg hover:shadow-xl transform hover:scale-105 transition duration-200',
    ])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Users\fajar\Downloads\shibaazaki\vendor\resources\views/components/primary-button.blade.php ENDPATH**/ ?>