
<?php $__env->startSection('title', 'UPS Brands - Shibaazaki'); ?>
<?php $__env->startSection('content'); ?>
    <header
        class="w-full pt-[74px] pb-[34px] bg-[url('https://images.pexels.com/photos/8071904/pexels-photo-8071904.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')] bg-cover bg-no-repeat bg-center relative z-0">
        <div class="container max-w-[1130px] mx-auto flex flex-col items-center justify-center gap-[34px] z-10">
            <div class="flex flex-col gap-2 text-center w-fit mt-20 z-10">
                <h1 class="font-semibold text-2xl lg:text-[60px] leading-[130%]">Brand UPS Kami</h1>
            </div>
            <div class="flex w-full justify-center mb-[34px] z-10">
                <form method="GET" action="<?php echo e(route('front.ups-brands.index')); ?>"
                    class="group/search-bar p-[14px_18px] bg-belibang-darker-grey ring-1 ring-[#414141] hover:ring-[#888888] max-w-[560px] w-full rounded-full transition-all duration-300">
                    <div class="relative text-left">
                        <button type="submit" class="absolute inset-y-0 left-0 flex items-center">
                            <img src="../assets/images/icons/search-normal.svg" alt="icon">
                        </button>
                        <input type="text" name="search" id="searchInput" value="<?php echo e(request('search')); ?>"
                            class="bg-belibang-darker-grey w-full pl-[36px] focus:outline-none placeholder:text-[#595959] pr-9"
                            placeholder="Type anything to search..." />
                        <button type="button" id="resetButton"
                            class="close-button <?php echo e(request('search') ? 'flex' : 'hidden'); ?> w-[38px] h-[38px] shrink-0 bg-[url('../assets/images/icons/close.svg')] hover:bg-[url('../assets/images/icons/close-white.svg')] transition-all duration-300 appearance-none transform -translate-x-1/2 -translate-y-1/2 absolute top-1/2 -right-5"
                            onclick="clearSearch()">
                        </button>
                    </div>
                </form>
            </div>
        </div>
        <div class="w-full h-full absolute top-0 bg-gradient-to-b from-belibang-black/70 to-belibang-black z-0"></div>
    </header>
    <section id="NewProduct"
        class="container max-w-[1230px] mx-auto mb-16 md:mb-24 lg:mb-[102px] flex flex-col gap-6 md:gap-8 px-4 sm:px-6 lg:px-8">
        <!-- Responsive Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5 md:gap-6 lg:gap-[22px]">
            <?php $__empty_1 = true; $__currentLoopData = $upsBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <!-- Product Card -->
                <div class="product-card flex flex-col rounded-xl md:rounded-[18px] bg-[#181818] overflow-hidden">
                    <a href="details.html"
                        class="thumbnail w-full h-[160px] sm:h-[170px] md:h-[180px] lg:h-[180px] flex shrink-0 overflow-hidden relative">
                        <img src="<?php echo e(Storage::url($item->image)); ?>" class="w-full h-full object-cover"
                            alt="<?php echo e($item->name); ?>" />
                    </a>
                    <div class="p-3 sm:p-4 md:p-[10px_14px_12px] h-full flex flex-col justify-between gap-3 md:gap-[14px]">
                        <div class="flex flex-col gap-1">
                            <a href="details.html"
                                class="font-bold text-base sm:text-lg md:text-xl lg:text-2xl mb-2 leading-snug line-clamp-2">
                                <?php echo e($item->name); ?>

                            </a>
                        </div>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p class="text-gray-600">No products found.</p>
            <?php endif; ?>
        </div>
        <!-- Load More Button -->
        <div class="text-center mt-12">
            
            <?php echo e($upsBrands->links()); ?>

        </div>
    </section>
    <script>
        function clearSearch() {
            document.getElementById('searchInput').value = '';
            window.location.href = "<?php echo e(route('front.ups-brands.index')); ?>";
        }
    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\CODING\shibaazaki-website\resources\views/front/ups-brands/index.blade.php ENDPATH**/ ?>