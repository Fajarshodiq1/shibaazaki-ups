<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'id' => 'image',
    'name' => 'image',
    'label' => 'Upload Image',
    'optional' => false,
    'recommended' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'id' => 'image',
    'name' => 'image',
    'label' => 'Upload Image',
    'optional' => false,
    'recommended' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div>
    <!-- Label -->
    <div class="flex items-center space-x-2 mb-2">
        <i class="fas fa-image text-indigo-500"></i>
        <?php if (isset($component)) { $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-label','data' => ['for' => $id,'value' => $label,'class' => 'text-base font-medium']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['for' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($id),'value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($label),'class' => 'text-base font-medium']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $attributes = $__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__attributesOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581)): ?>
<?php $component = $__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581; ?>
<?php unset($__componentOriginale3da9d84bb64e4bc2eeebaafabfb2581); ?>
<?php endif; ?>
        <?php if($optional): ?>
            <span class="text-gray-400 text-sm">(Optional)</span>
        <?php endif; ?>
    </div>

    <!-- Upload Area -->
    <div class="relative">
        <input id="<?php echo e($id); ?>" name="<?php echo e($name); ?>" type="file" class="hidden"
            onchange="previewImage('<?php echo e($id); ?>')" />
        <label for="<?php echo e($id); ?>"
            class="flex flex-col items-center justify-center w-full h-48 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition-colors duration-200">
            <div class="flex flex-col items-center justify-center pt-5 pb-6" id="uploadArea-<?php echo e($id); ?>">
                <i class="fas fa-cloud-upload-alt text-4xl text-gray-400 mb-4"></i>
                <p class="mb-2 text-sm text-gray-500">
                    <span class="font-semibold">Click to upload</span> or drag and drop
                </p>
                <p class="text-xs text-gray-500">PNG, JPG, JPEG or GIF (MAX. 2MB)</p>
            </div>
            <img id="preview-<?php echo e($id); ?>" class="hidden w-full h-full rounded-lg object-contain bg-white" />
        </label>
    </div>

    <!-- Error -->
    <?php if (isset($component)) { $__componentOriginalf94ed9c5393ef72725d159fe01139746 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf94ed9c5393ef72725d159fe01139746 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.input-error','data' => ['messages' => $errors->get($name),'class' => 'mt-2']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('input-error'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['messages' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors->get($name)),'class' => 'mt-2']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $attributes = $__attributesOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__attributesOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf94ed9c5393ef72725d159fe01139746)): ?>
<?php $component = $__componentOriginalf94ed9c5393ef72725d159fe01139746; ?>
<?php unset($__componentOriginalf94ed9c5393ef72725d159fe01139746); ?>
<?php endif; ?>

    <!-- Recommended size -->
    <?php if($recommended): ?>
        <div class="flex items-center space-x-2 text-sm text-gray-500 mt-1">
            <i class="fas fa-info-circle"></i>
            <span>Recommended size: <?php echo e($recommended); ?></span>
        </div>
    <?php endif; ?>
</div>
<script>
    // Image preview functionality
    function previewImage(id) {
        const input = document.getElementById(id);
        const file = input.files[0];
        const preview = document.getElementById('preview-' + id);
        const uploadArea = document.getElementById('uploadArea-' + id);

        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.classList.remove('hidden');
                uploadArea.classList.add('hidden');
            }
            reader.readAsDataURL(file);
        } else {
            preview.classList.add('hidden');
            uploadArea.classList.remove('hidden');
        }
    }

    // Character counter for description
    document.getElementById('description').addEventListener('input', function() {
        const current = this.value.length;
        const max = 500;
        document.getElementById('charCount').textContent = current + '/' + max + ' characters';

        if (current > max * 0.9) {
            document.getElementById('charCount').classList.add('text-red-500');
        } else {
            document.getElementById('charCount').classList.remove('text-red-500');
        }
    });

    // Status text update
    function updateStatusText(checkbox) {
        const statusText = document.getElementById('statusText');
        statusText.textContent = checkbox.checked ? 'Active' : 'Inactive';
        statusText.className = checkbox.checked ? 'text-sm text-green-600' : 'text-sm text-gray-600';
    }

    // Form validation enhancement
    document.getElementById('categoryForm').addEventListener('submit', function(e) {
        const nameInput = document.getElementById('name');
        if (!nameInput.value.trim()) {
            e.preventDefault();
            nameInput.focus();
            nameInput.classList.add('border-red-500');

            // Show error message
            const errorDiv = document.createElement('div');
            errorDiv.className = 'text-red-500 text-sm mt-1';
            errorDiv.textContent = 'Category name is required';
            nameInput.parentNode.appendChild(errorDiv);

            setTimeout(() => {
                errorDiv.remove();
                nameInput.classList.remove('border-red-500');
            }, 3000);
        }
    });

    // Auto-resize textarea
    document.getElementById('description').addEventListener('input', function() {
        this.style.height = 'auto';
        this.style.height = Math.min(this.scrollHeight, 200) + 'px';
    });
</script>
<?php /**PATH C:\CODING\shibaazaki-website\resources\views/components/image-upload.blade.php ENDPATH**/ ?>