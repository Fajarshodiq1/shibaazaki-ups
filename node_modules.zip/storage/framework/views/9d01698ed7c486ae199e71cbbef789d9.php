
<?php $__env->startSection('title', 'UPS Brands - Shibaazaki'); ?>
<?php $__env->startSection('meta_title', 'UPS Brands - Shibaazaki'); ?>
<?php $__env->startSection('meta_description',
    'Kami menyediakan berbagai brand UPS berkualitas untuk memenuhi kebutuhan daya tak terputus
    Anda.'); ?>
<?php $__env->startSection('meta_keywords', 'ups, brand ups, shibaazaki, jual ups, sewa ups, rental ups, maintenance ups'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal676d920e8bb32a4c96cd6e6c6ba00de0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal676d920e8bb32a4c96cd6e6c6ba00de0 = $attributes; } ?>
<?php $component = App\View\Components\HeroHeader::resolve(['title' => 'Brand UPS Kami','subtitle' => 'Kami menyediakan berbagai brand UPS berkualitas'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hero-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\HeroHeader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal676d920e8bb32a4c96cd6e6c6ba00de0)): ?>
<?php $attributes = $__attributesOriginal676d920e8bb32a4c96cd6e6c6ba00de0; ?>
<?php unset($__attributesOriginal676d920e8bb32a4c96cd6e6c6ba00de0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal676d920e8bb32a4c96cd6e6c6ba00de0)): ?>
<?php $component = $__componentOriginal676d920e8bb32a4c96cd6e6c6ba00de0; ?>
<?php unset($__componentOriginal676d920e8bb32a4c96cd6e6c6ba00de0); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['items' => [['label' => 'Beranda', 'url' => route('pages.home')], ['label' => 'Brand UPS']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal61542037d001e2034791c9aff5866543 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal61542037d001e2034791c9aff5866543 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search-bar','data' => ['action' => route('front.ups-brands.index'),'placeholder' => 'Cari Brand UPS...','collection' => $upsBrands,'label' => 'brand']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('search-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('front.ups-brands.index')),'placeholder' => 'Cari Brand UPS...','collection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($upsBrands),'label' => 'brand']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal61542037d001e2034791c9aff5866543)): ?>
<?php $attributes = $__attributesOriginal61542037d001e2034791c9aff5866543; ?>
<?php unset($__attributesOriginal61542037d001e2034791c9aff5866543); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal61542037d001e2034791c9aff5866543)): ?>
<?php $component = $__componentOriginal61542037d001e2034791c9aff5866543; ?>
<?php unset($__componentOriginal61542037d001e2034791c9aff5866543); ?>
<?php endif; ?>
    <section id="NewProduct"
        class="container max-w-7xl mx-auto mb-16 md:mb-24 lg:mb-[102px] flex flex-col gap-6 md:gap-8 px-5">
        <!-- Responsive Grid -->
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5 md:gap-6 lg:gap-[22px]">
            <?php $__empty_1 = true; $__currentLoopData = $upsBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <!-- Product Card -->
                <div class="product-card flex flex-col rounded-xl md:rounded-[18px] bg-[#181818] overflow-hidden">
                    <a href="<?php echo e(route('front.ups-brands.show', $item->slug)); ?>"
                        class="thumbnail w-full h-[160px] sm:h-[170px] md:h-[180px] lg:h-[180px] flex shrink-0 overflow-hidden relative">
                        <img src="<?php echo e(Storage::url($item->image)); ?>" class="w-full h-full object-cover"
                            alt="<?php echo e($item->name); ?>" />
                    </a>
                    <div class="p-3 sm:p-4 md:p-[10px_14px_12px] h-full flex flex-col justify-between gap-3 md:gap-[14px]">
                        <div class="flex flex-col gap-1">
                            <a href="<?php echo e(route('front.ups-brands.show', $item->slug)); ?>"
                                class="font-bold text-base sm:text-lg md:text-xl lg:text-2xl mb-2 leading-snug line-clamp-2">
                                <?php echo e($item->name); ?>

                            </a>
                        </div>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php if (isset($component)) { $__componentOriginal0530b040de3f239c08ad8ba7f82c77bd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0530b040de3f239c08ad8ba7f82c77bd = $attributes; } ?>
<?php $component = App\View\Components\EmptyState::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('empty-state'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\EmptyState::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Brand UPS tidak ditemukan','message' => 'Coba lagi dengan kata kunci lain.']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0530b040de3f239c08ad8ba7f82c77bd)): ?>
<?php $attributes = $__attributesOriginal0530b040de3f239c08ad8ba7f82c77bd; ?>
<?php unset($__attributesOriginal0530b040de3f239c08ad8ba7f82c77bd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0530b040de3f239c08ad8ba7f82c77bd)): ?>
<?php $component = $__componentOriginal0530b040de3f239c08ad8ba7f82c77bd; ?>
<?php unset($__componentOriginal0530b040de3f239c08ad8ba7f82c77bd); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
        <!-- Load More Button -->
        <div class="text-center mt-12">
            
            <?php echo e($upsBrands->links()); ?>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\fajar\Downloads\shibaazaki\vendor\resources\views/front/ups-brands/index.blade.php ENDPATH**/ ?>