
<?php /**PATH C:\CODING\shibaazaki-website\resources\views/category/show.blade.php ENDPATH**/ ?>