<div class="flex justify-between items-center">
    <div>
        <h2 class="font-bold text-2xl text-gray-900 leading-tight">
            <?php echo e($title); ?>

        </h2>
        <?php if($subtitle): ?>
            <p class="text-gray-600 text-sm mt-1"><?php echo e($subtitle); ?></p>
        <?php endif; ?>
    </div>

    <?php if($buttonRoute && $buttonText): ?>
        <a href="<?php echo e(route($buttonRoute)); ?>"
            class="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 
                   hover:from-blue-700 hover:to-blue-800 text-white font-semibold rounded-lg 
                   shadow-lg hover:shadow-xl transform hover:scale-105 transition duration-200">
            <?php echo e($buttonText); ?>

        </a>
    <?php endif; ?>
</div>
<?php /**PATH C:\CODING\shibaazaki-website\resources\views/components/page-header.blade.php ENDPATH**/ ?>