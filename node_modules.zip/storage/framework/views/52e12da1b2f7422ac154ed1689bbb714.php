<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'action' => '#', // route tujuan form
    'placeholder' => 'Search...',
    'collection' => null, // paginator/collection
    'label' => 'item', // label untuk count (ex: brand, artikel, produk)
    'search' => request('search'), // default ambil dari query
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'action' => '#', // route tujuan form
    'placeholder' => 'Search...',
    'collection' => null, // paginator/collection
    'label' => 'item', // label untuk count (ex: brand, artikel, produk)
    'search' => request('search'), // default ambil dari query
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<section class="container max-w-7xl mx-auto mb-8 md:mb-12 px-5 mt-5">
    <div class="bg-[#181818] rounded-xl md:rounded-[18px] p-4 sm:p-6 md:p-8">
        <div class="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">

            <!-- Search Form -->
            <form method="GET" action="<?php echo e($action); ?>" class="flex-1 w-full sm:max-w-md">
                <div class="relative">
                    <!-- Icon -->
                    <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                        <svg class="h-5 w-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                    </div>

                    <!-- Input -->
                    <input type="text" name="search" value="<?php echo e($search); ?>" placeholder="<?php echo e($placeholder); ?>"
                        class="block w-full pl-10 pr-4 py-3 border border-gray-600 rounded-full bg-[#2a2a2a] text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all duration-200" />

                    <!-- Clear Button -->
                    <?php if($search): ?>
                        <a href="<?php echo e($action); ?>" class="absolute inset-y-0 right-0 pr-3 flex items-center">
                            <svg class="h-5 w-5 text-gray-400 hover:text-white transition-colors" fill="none"
                                stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M6 18L18 6M6 6l12 12" />
                            </svg>
                        </a>
                    <?php endif; ?>
                </div>
            </form>

            <!-- Search Results Info -->
            <div class="flex flex-col sm:flex-row gap-2 sm:gap-4 items-start sm:items-center text-sm text-gray-400">
                <?php if($search): ?>
                    <span class="whitespace-nowrap">
                        Found <?php echo e($collection?->total() ?? 0); ?>

                        <?php echo e(Str::plural($label, $collection?->total() ?? 0)); ?>

                        for <span class="text-white font-medium">"<?php echo e($search); ?>"</span>
                    </span>
                <?php else: ?>
                    <span class="whitespace-nowrap">
                        Showing <?php echo e($collection?->total() ?? 0); ?>

                        <?php echo e(Str::plural($label, $collection?->total() ?? 0)); ?>

                    </span>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\Users\fajar\Downloads\shibaazaki\vendor\resources\views/components/search-bar.blade.php ENDPATH**/ ?>