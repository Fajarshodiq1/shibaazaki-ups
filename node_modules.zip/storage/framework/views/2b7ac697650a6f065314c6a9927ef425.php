<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['items']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['items']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<nav class="flex w-full overflow-x-auto text-sm sm:text-base max-w-7xl mx-auto px-5" aria-label="Breadcrumb">
    <ol class="inline-flex items-center space-x-1 sm:space-x-2">
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="inline-flex items-center">
                <?php if(isset($item['url'])): ?>
                    <a href="<?php echo e($item['url']); ?>"
                        class="inline-flex items-center text-gray-400 hover:text-white transition-colors">
                        <?php if($index === 0): ?>
                            <!-- Home icon modern -->
                            <svg xmlns="http://www.w3.org/2000/svg"
                                class="w-4 h-4 mr-1 text-gray-400 group-hover:text-white transition-colors duration-300"
                                fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round"
                                    d="M3 9.75L12 3l9 6.75V21a1 1 0 01-1 1h-5.25a.75.75 0 01-.75-.75V15h-4.5v6.25c0 .414-.336.75-.75.75H4a1 1 0 01-1-1V9.75z" />
                            </svg>
                        <?php endif; ?>
                        <?php echo e($item['label']); ?>

                    </a>
                <?php else: ?>
                    <span class="text-white font-medium"><?php echo e($item['label']); ?></span>
                <?php endif; ?>
            </li>

            <?php if(!$loop->last): ?>
                <!-- Separator -->
                <li>
                    <svg class="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7" />
                    </svg>
                </li>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</nav>
<?php /**PATH C:\Users\fajar\Downloads\shibaazaki\vendor\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>