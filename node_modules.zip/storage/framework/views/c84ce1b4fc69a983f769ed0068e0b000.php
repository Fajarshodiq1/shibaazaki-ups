
<?php $__env->startSection('title', 'UPS Brands - Shibaazaki'); ?>
<?php $__env->startSection('meta_title', 'UPS Brands - ' . $upsBrand->name); ?>
<?php $__env->startSection('meta_description', 'Detail tentang brand UPS ' . $upsBrand->name); ?>
<?php $__env->startSection('meta_keywords', 'ups, brand ups, ' . $upsBrand->name . ', ' . $upsBrand->name . ' ups'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal676d920e8bb32a4c96cd6e6c6ba00de0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal676d920e8bb32a4c96cd6e6c6ba00de0 = $attributes; } ?>
<?php $component = App\View\Components\HeroHeader::resolve(['title' => 'Brand UPS Kami','subtitle' => 'Kami menyediakan berbagai brand UPS berkualitas'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hero-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\HeroHeader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal676d920e8bb32a4c96cd6e6c6ba00de0)): ?>
<?php $attributes = $__attributesOriginal676d920e8bb32a4c96cd6e6c6ba00de0; ?>
<?php unset($__attributesOriginal676d920e8bb32a4c96cd6e6c6ba00de0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal676d920e8bb32a4c96cd6e6c6ba00de0)): ?>
<?php $component = $__componentOriginal676d920e8bb32a4c96cd6e6c6ba00de0; ?>
<?php unset($__componentOriginal676d920e8bb32a4c96cd6e6c6ba00de0); ?>
<?php endif; ?>
    <section class="container max-w-[1230px] mx-auto px-5 my-5">
        <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['items' => [
            ['label' => 'Home', 'url' => '/'],
            ['label' => 'UPS Brands', 'url' => route('front.ups-brands.index')],
            ['label' => $upsBrand->name],
        ]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
    </section>
    <!-- Product Detail -->
    <section class="container max-w-[1230px] mx-auto mb-16 px-5">
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <!-- Product Image -->
            <div class="lg:sticky lg:top-24 h-fit self-start">
                <div class="aspect-square bg-[#181818] rounded-2xl overflow-hidden border border-gray-800">
                    <img src="<?php echo e($upsBrand->image ? asset('storage/' . $upsBrand->image) : 'https://via.placeholder.com/600x600?text=UPS'); ?>"
                        class="w-full h-full object-cover" alt="<?php echo e($upsBrand->name); ?>">
                </div>
            </div>
            <!-- Product Info -->
            <div class="space-y-6">
                <!-- Title & Brand -->
                <div>
                    <h1 class="text-3xl md:text-4xl font-bold text-white mb-2"><?php echo e($upsBrand->name); ?></h1>
                </div>

                <!-- Description -->
                <?php if($upsBrand->description): ?>
                    <div class="bg-[#181818] rounded-2xl p-6 border border-gray-800">
                        <h3 class="text-xl font-semibold text-white mb-4">Deskripsi</h3>
                        <div class="text-gray-300 leading-relaxed prose prose-invert"><?php echo $upsBrand->description; ?></div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\fajar\Downloads\shibaazaki\vendor\resources\views/front/ups-brands/show.blade.php ENDPATH**/ ?>