
<?php $__env->startSection('title', 'PT Shibaazaki - Rental UPS'); ?>
<?php $__env->startSection('meta_description', 'Temukan harga sewa UPS terbaik untuk kebutuhan bisnis Anda dengan berbagai pilihan durasi
    rental'); ?>
<?php $__env->startSection('meta_keywords', 'rental ups, sewa ups, harga rental ups, harga sewa ups, rental ups jakarta, rental ups
    bekasi, rental ups tangerang, rental ups depok, rental ups bogor'); ?>
<?php $__env->startSection('content'); ?>
    <?php if (isset($component)) { $__componentOriginal676d920e8bb32a4c96cd6e6c6ba00de0 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal676d920e8bb32a4c96cd6e6c6ba00de0 = $attributes; } ?>
<?php $component = App\View\Components\HeroHeader::resolve(['title' => 'Rental UPS','subtitle' => 'Temukan harga sewa UPS terbaik untuk kebutuhan bisnis Anda dengan berbagai pilihan durasi rental'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('hero-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\HeroHeader::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal676d920e8bb32a4c96cd6e6c6ba00de0)): ?>
<?php $attributes = $__attributesOriginal676d920e8bb32a4c96cd6e6c6ba00de0; ?>
<?php unset($__attributesOriginal676d920e8bb32a4c96cd6e6c6ba00de0); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal676d920e8bb32a4c96cd6e6c6ba00de0)): ?>
<?php $component = $__componentOriginal676d920e8bb32a4c96cd6e6c6ba00de0; ?>
<?php unset($__componentOriginal676d920e8bb32a4c96cd6e6c6ba00de0); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal269900abaed345884ce342681cdc99f6 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal269900abaed345884ce342681cdc99f6 = $attributes; } ?>
<?php $component = App\View\Components\Breadcrumb::resolve(['items' => [['label' => 'Beranda', 'url' => route('pages.home')], ['label' => 'Rental UPS']]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Breadcrumb::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $attributes = $__attributesOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__attributesOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal269900abaed345884ce342681cdc99f6)): ?>
<?php $component = $__componentOriginal269900abaed345884ce342681cdc99f6; ?>
<?php unset($__componentOriginal269900abaed345884ce342681cdc99f6); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal61542037d001e2034791c9aff5866543 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal61542037d001e2034791c9aff5866543 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.search-bar','data' => ['action' => route('rental.index'),'placeholder' => 'Cari produk rental...','collection' => $products,'label' => 'produk rental']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('search-bar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['action' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('rental.index')),'placeholder' => 'Cari produk rental...','collection' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($products),'label' => 'produk rental']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal61542037d001e2034791c9aff5866543)): ?>
<?php $attributes = $__attributesOriginal61542037d001e2034791c9aff5866543; ?>
<?php unset($__attributesOriginal61542037d001e2034791c9aff5866543); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal61542037d001e2034791c9aff5866543)): ?>
<?php $component = $__componentOriginal61542037d001e2034791c9aff5866543; ?>
<?php unset($__componentOriginal61542037d001e2034791c9aff5866543); ?>
<?php endif; ?>
    <!-- Products Section -->
    <section class="container max-w-7xl mx-auto mb-20 px-5">
        <?php if($products->count() > 0): ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div
                        class="rental-card flex flex-col rounded-3xl bg-belibang-darker-grey overflow-hidden hover:transform hover:scale-105 transition-all duration-300 border border-gray-800 hover:border-gray-600">
                        <!-- Product Image -->
                        <a href="<?php echo e(route('rental.show', $product->slug)); ?>"
                            class="thumbnail w-full h-48 flex shrink-0 overflow-hidden relative">
                            <img src="<?php echo e($product->image ? asset('storage/' . $product->image) : 'https://via.placeholder.com/300x200?text=UPS'); ?>"
                                class="w-full h-full object-cover" alt="<?php echo e($product->name); ?>" />
                        </a>

                        <!-- Product Info -->
                        <div class="p-4 h-full flex flex-col justify-between">
                            <div class="flex flex-col gap-3 mb-6">
                                <!-- Product Name & Brand -->
                                <div>
                                    <a href="<?php echo e(route('rental.show', $product->slug)); ?>"
                                        class="font-bold text-lg text-white hover:text-blue-400 transition-colors line-clamp-2">
                                        <?php echo e($product->name); ?>

                                    </a>
                                    <p class="text-gray-400 text-sm"><?php echo e($product->brand); ?></p>
                                </div>

                                <!-- Capacity -->
                                <?php if($product->capacity): ?>
                                    <div class="flex items-center gap-2">
                                        <span class="bg-gray-700 text-gray-300 px-2 py-1 rounded text-xs">
                                            <?php echo e($product->capacity); ?>

                                        </span>
                                    </div>
                                <?php endif; ?>

                                <!-- Rental Prices -->
                                <div class="space-y-2">
                                    <?php $__currentLoopData = $product->rentalPrices->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="flex justify-between items-center">
                                            <span class="text-gray-400 text-sm capitalize"><?php echo e($rental->duration); ?></span>
                                            <span class="text-white font-semibold"><?php echo e($rental->formatted_price); ?></span>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php if($product->rentalPrices->count() > 3): ?>
                                        <p class="text-blue-400 text-xs">+<?php echo e($product->rentalPrices->count() - 3); ?>

                                            more options</p>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Action Button -->
                            <?php if (isset($component)) { $__componentOriginal65d447e2e1d6d1280f71c2839641b3e5 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal65d447e2e1d6d1280f71c2839641b3e5 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.front-button-primary','data' => ['href' => ''.e(route('rental.show', $product->slug)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('front-button-primary'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('rental.show', $product->slug)).'']); ?>
                                Lihat Detail Rental
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal65d447e2e1d6d1280f71c2839641b3e5)): ?>
<?php $attributes = $__attributesOriginal65d447e2e1d6d1280f71c2839641b3e5; ?>
<?php unset($__attributesOriginal65d447e2e1d6d1280f71c2839641b3e5); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal65d447e2e1d6d1280f71c2839641b3e5)): ?>
<?php $component = $__componentOriginal65d447e2e1d6d1280f71c2839641b3e5; ?>
<?php unset($__componentOriginal65d447e2e1d6d1280f71c2839641b3e5); ?>
<?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <!-- Pagination -->
            <div class="mt-12 flex justify-center">
                <?php echo e($products->links('pagination::tailwind')); ?>

            </div>
        <?php else: ?>
            <!-- Empty State -->
            <div class="text-center py-16">
                <div class="max-w-md mx-auto">
                    <div class="text-gray-500 mb-4">
                        <svg class="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z">
                            </path>
                        </svg>
                    </div>
                    <h3 class="text-xl font-semibold text-gray-400 mb-2">Tidak ada produk rental ditemukan</h3>
                    <p class="text-gray-500 mb-7">Coba ubah filter pencarian Anda atau hapus beberapa filter</p>
                    <a href="<?php echo e(route('rental.index')); ?>"
                        class="bg-img-purple-to-orange text-white font-semibold py-3 px-5 rounded-full transition-colors duration-200">
                        Reset Filter
                    </a>
                </div>
            </div>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\fajar\Downloads\shibaazaki\vendor\resources\views/front/rental/index.blade.php ENDPATH**/ ?>