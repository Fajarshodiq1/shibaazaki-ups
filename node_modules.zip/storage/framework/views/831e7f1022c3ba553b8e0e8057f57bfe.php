

<?php $__env->startSection('title', $category->name); ?>
<?php $__env->startSection('description', $category->description); ?>
<?php $__env->startSection('keywords', $category->name . ', ' . $category->description); ?>

<?php $__env->startSection('content'); ?>
    <header class="w-full pt-16 md:pt-[74px] h-[30vh] bg-cover bg-no-repeat bg-center relative z-0"
        style="background-image: url('https://images.pexels.com/photos/8071904/pexels-photo-8071904.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1');">
        <!-- Overlay Gradient -->
        <div class="w-full h-full absolute top-0 bg-gradient-to-b from-belibang-black/70 to-belibang-black z-0"></div>
    </header>
    <!-- Header Section -->
    <section class="container max-w-[1230px] mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Category Header -->
        <div class="mb-12">
            <div class="flex flex-col lg:flex-row items-start lg:items-center gap-6">
                <div class="w-[80px] h-[80px] flex items-center justify-center p-4 rounded-full bg-white">
                    <img src="<?php echo e(Storage::url($category->image)); ?>" alt="UPS Icon"
                        class="max-w-full max-h-full object-contain">
                </div>
                <div class="flex-1">
                    <h1 class="font-bold text-3xl sm:text-4xl lg:text-5xl mb-4"><?php echo e($category->name); ?></h1>
                    <div class="prose text-lg text-belibang-grey leading-relaxed">
                        <?php echo $category->description; ?>

                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Filter Section -->
    

    <!-- Products Grid -->
    <section class="container max-w-[1230px] mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6" id="products-grid">
            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <!-- Product Card  -->
                <div class="product-card group p-[1px] rounded-2xl bg-img-transparent hover:bg-img-purple-to-orange transition-all duration-300"
                    data-brand="pascal" data-capacity="1" data-price="2500000">
                    <div
                        class="flex flex-col p-6 rounded-2xl bg-img-black-gradient group-hover:bg-img-black transition-all duration-300">
                        <div class="relative mb-4">
                            <img src="<?php echo e(Storage::url($item->image)); ?>" alt="Pascal UPS 1KVA"
                                class="w-full h-48 object-cover rounded-lg">
                            <span
                                class="absolute top-2 right-2 bg-green-600 text-white text-xs px-2 py-1 rounded-full"><?php echo e($item->brand); ?></span>
                        </div>
                        <div class="flex-1">
                            <div class="flex items-center justify-between mb-2">
                                <span
                                    class="text-xs bg-gray-700 text-gray-300 px-2 py-1 rounded-full"><?php echo e($item->category->name ?? ''); ?></span>
                                <span class="text-xs text-belibang-grey"><?php echo e($item->capacity ?? ''); ?></span>
                            </div>
                            <h3 class="font-bold text-lg mb-2"><?php echo e($item->name ?? ''); ?></h3>
                            <div class="text-sm text-belibang-grey mb-4 line-clamp-2 prose">
                                <?php echo $item->description ?? ''; ?>

                            </div>
                            <div class="flex items-center justify-between">
                                <div>
                                    <p class="text-xl font-bold text-belibang-orange">
                                        Rp <?php echo e(number_format($item->price ?? 0, 0, ',', '.')); ?>

                                    </p>

                                    <p class="text-xs text-belibang-grey">Stok: <?php echo e($item->stock ?? ''); ?> unit</p>
                                </div>
                                <a href="<?php echo e(route('products.show', $item->slug)); ?>"
                                    class="px-4 py-2 bg-img-purple-to-orange rounded-lg text-sm font-medium hover:opacity-90 transition-opacity">
                                    Detail
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-span-1">
                    <p class="text-center text-gray-500">Tidak ada produk yang ditemukan.</p>
                </div>
            <?php endif; ?>
        </div>

        <!-- Load More Button -->
        <div class="text-center mt-12">
            
            <?php echo e($products->links()); ?>

        </div>
    </section>
    <script>
        // Filter functionality
        const filterButtons = document.querySelectorAll('.filter-btn');
        const productCards = document.querySelectorAll('.product-card');
        const sortSelect = document.getElementById('sort');

        // Filter by brand
        filterButtons.forEach(button => {
            button.addEventListener('click', () => {
                // Remove active class from all buttons
                filterButtons.forEach(btn => btn.classList.remove('active'));
                // Add active class to clicked button
                button.classList.add('active');

                const filter = button.dataset.filter;

                productCards.forEach(card => {
                    if (filter === 'all' || card.dataset.brand === filter) {
                        card.style.display = 'block';
                    } else {
                        card.style.display = 'none';
                    }
                });
            });
        });

        // Sort functionality
        sortSelect.addEventListener('change', () => {
            const sortValue = sortSelect.value;
            const productsGrid = document.getElementById('products-grid');
            const cards = Array.from(productCards);

            cards.sort((a, b) => {
                switch (sortValue) {
                    case 'name':
                        const nameA = a.querySelector('h3').textContent;
                        const nameB = b.querySelector('h3').textContent;
                        return nameA.localeCompare(nameB);
                    case 'price-low':
                        const priceA = parseInt(a.dataset.price);
                        const priceB = parseInt(b.dataset.price);
                        return priceA - priceB;
                    case 'price-high':
                        const priceA2 = parseInt(a.dataset.price);
                        const priceB2 = parseInt(b.dataset.price);
                        return priceB2 - priceA2;
                    case 'capacity':
                        const capA = parseInt(a.dataset.capacity);
                        const capB = parseInt(b.dataset.capacity);
                        return capA - capB;
                    default:
                        return 0;
                }
            });

            // Clear and re-append sorted cards
            productsGrid.innerHTML = '';
            cards.forEach(card => productsGrid.appendChild(card));
        });

        // Smooth scroll for anchor links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\CODING\shibaazaki-website\resources\views/front/category/index.blade.php ENDPATH**/ ?>