<p
    <?php echo e($attributes->merge([
        'class' => 'text-[15px] md:text-base lg:text-lg text-gray-300 leading-relaxed text-left md:text-justify',
    ])); ?>>
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\Users\fajar\Downloads\shibaazaki\vendor\resources\views/components/paragraph.blade.php ENDPATH**/ ?>