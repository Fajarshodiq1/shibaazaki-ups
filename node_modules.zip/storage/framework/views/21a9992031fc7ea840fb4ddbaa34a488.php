
<?php $__env->startSection('content'); ?>
    <header
        class="w-full pt-20 pb-8 sm:pt-24 sm:pb-12 bg-[url('https://images.pexels.com/photos/8071904/pexels-photo-8071904.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')] bg-cover bg-no-repeat bg-center relative z-0">
        <div class="container max-w-[1130px] mx-auto flex flex-col items-center justify-center gap-6 sm:gap-8 z-10">

            <!-- Judul -->
            <div class="flex flex-col gap-2 text-center w-fit mt-10 sm:mt-20 z-10">
                <h1 class="font-semibold text-3xl sm:text-4xl md:text-5xl lg:text-[60px] leading-snug sm:leading-[120%]">
                    Artikel Terbaru
                </h1>
            </div>

            <!-- Search Bar -->
            <div class="flex w-full justify-center mb-8 sm:mb-10 z-10 px-4">
                <form method="GET" action="<?php echo e(route('front.post.index')); ?>"
                    class="group/search-bar flex items-center p-3 bg-belibang-darker-grey ring-1 ring-[#414141] hover:ring-[#888888] w-full max-w-full sm:max-w-[480px] md:max-w-[560px] rounded-full transition-all duration-300">
                    <div class="relative flex-1">
                        <button type="submit" class="absolute inset-y-0 left-0 flex items-center pl-2">
                            <img src="../assets/images/icons/search-normal.svg" alt="icon"
                                class="w-5 h-5 sm:w-6 sm:h-6">
                        </button>
                        <input type="text" name="search" id="searchInput" value="<?php echo e(request('search')); ?>"
                            class="bg-belibang-darker-grey w-full pl-9 pr-10 text-sm sm:text-base focus:outline-none placeholder:text-[#595959]"
                            placeholder="Cari artikel..." />
                        <button type="button" id="resetButton"
                            class="close-button <?php echo e(request('search') ? 'flex' : 'hidden'); ?> w-8 h-8 bg-[url('../assets/images/icons/close.svg')] hover:bg-[url('../assets/images/icons/close-white.svg')] transition-all duration-300 appearance-none absolute top-1/2 -translate-y-1/2 right-0 mr-2">
                        </button>
                    </div>
                </form>
            </div>
        </div>

        <!-- Overlay -->
        <div class="w-full h-full absolute top-0 bg-gradient-to-b from-belibang-black/70 to-belibang-black z-0"></div>
    </header>

    <section class="container max-w-[1230px] mx-auto px-4 sm:px-6 lg:px-8 mb-16">
        <?php if(request('search')): ?>
            <div class="mb-6">
                <p class="text-gray-400">
                    Showing results for: <span class="text-white font-semibold">"<?php echo e(request('search')); ?>"</span>
                    <span class="text-gray-400">(<?php echo e($posts->total()); ?> <?php echo e($posts->total() == 1 ? 'result' : 'results'); ?>

                        found)</span>
                </p>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="product-card group p-[1px] rounded-2xl bg-img-transparent hover:bg-img-purple-to-orange transition-all duration-300"
                    data-brand="pascal" data-capacity="1" data-price="2500000">
                    <div
                        class="flex flex-col p-6 rounded-2xl bg-img-black-gradient group-hover:bg-img-black transition-all duration-300">
                        <div class="relative mb-4">
                            <img src="<?php echo e(Storage::url($item->thumbnail)); ?>" alt="gambar"
                                class="w-full h-48 object-cover rounded-lg">
                        </div>
                        <div class="flex-1">
                            <div class="flex items-center justify-between mb-2">
                                <span
                                    class="text-xs bg-gray-700 text-gray-300 px-2 py-1 rounded-full"><?php echo e($item->author->name); ?></span>
                            </div>
                            <h3 class="font-bold text-lg mb-2"><?php echo e($item->title); ?></h3>
                            <div class="text-sm text-belibang-grey mb-4 line-clamp-2 prose">
                                <?php echo $item->content; ?>

                            </div>

                            <a href="<?php echo e(route('front.post.show', $item->slug)); ?>"
                                class="inline-flex items-center justify-center px-4 py-2 bg-img-purple-to-orange rounded-lg text-sm font-medium hover:opacity-90 transition-opacity w-full">
                                Detail
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-span-full text-center py-12">
                    <div class="text-gray-400 mb-4">
                        <?php if(request('search')): ?>
                            <svg class="w-16 h-16 mx-auto mb-4 text-gray-600" fill="none" stroke="currentColor"
                                viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1"
                                    d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path>
                            </svg>
                            <h3 class="text-lg font-semibold mb-2">No results found</h3>
                            <p>No posts found for "<?php echo e(request('search')); ?>"</p>
                            <a href="<?php echo e(route('front.post.index')); ?>"
                                class="inline-block mt-4 px-4 py-2 bg-img-purple-to-orange rounded-lg text-sm font-medium hover:opacity-90 transition-opacity">
                                Show All Posts
                            </a>
                        <?php else: ?>
                            <h3 class="text-lg font-semibold">No posts found</h3>
                            <p>There are no posts available at the moment.</p>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>
        </div>

        <!-- Pagination -->
        <?php if($posts->hasPages()): ?>
            <div class="mt-12 flex justify-center">
                <?php echo e($posts->links()); ?>

            </div>
        <?php endif; ?>
    </section>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('searchInput');
            const resetButton = document.getElementById('resetButton');
            const form = searchInput.closest('form');

            // Show/hide reset button based on input content
            function toggleResetButton() {
                if (searchInput.value.trim() !== '') {
                    resetButton.classList.remove('hidden');
                    resetButton.classList.add('flex');
                } else {
                    resetButton.classList.add('hidden');
                    resetButton.classList.remove('flex');
                }
            }

            // Handle Enter key press
            searchInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    if (this.value.trim() !== '') {
                        form.submit();
                    } else {
                        // If empty, redirect to show all posts
                        window.location.href = '<?php echo e(route('front.post.index')); ?>';
                    }
                }
            });

            // Auto-submit after user stops typing (debounced)
            let searchTimeout;
            searchInput.addEventListener('input', function() {
                toggleResetButton();
                clearTimeout(searchTimeout);

                const searchValue = this.value.trim();

                searchTimeout = setTimeout(() => {
                    if (searchValue !== '') {
                        // If there's text and at least 3 characters, search
                        if (searchValue.length >= 3) {
                            form.submit();
                        }
                    } else {
                        // If empty, immediately redirect to show all posts
                        if ('<?php echo e(request('search')); ?>') {
                            window.location.href = '<?php echo e(route('front.post.index')); ?>';
                        }
                    }
                }, 500); // Reduced to 0.5 second for faster response when clearing
            });

            // Handle backspace and delete keys for immediate response when clearing
            searchInput.addEventListener('keyup', function(e) {
                if ((e.key === 'Backspace' || e.key === 'Delete') && this.value.trim() === '') {
                    clearTimeout(searchTimeout);
                    if ('<?php echo e(request('search')); ?>') {
                        window.location.href = '<?php echo e(route('front.post.index')); ?>';
                    }
                }
            });
        });

        // Clear search function
        function clearSearch() {
            const searchInput = document.getElementById('searchInput');
            searchInput.value = '';

            // Redirect to page without search parameter
            window.location.href = '<?php echo e(route('front.post.index')); ?>';
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\CODING\shibaazaki-website\resources\views/front/post/index.blade.php ENDPATH**/ ?>