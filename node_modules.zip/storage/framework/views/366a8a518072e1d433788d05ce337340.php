<h1 <?php echo e($attributes->merge(['class' => 'font-semibold text-2xl sm:text-[32px] lg:mb-1 text-center lg:text-start'])); ?>>
    <?php echo e($slot); ?>

</h1>
<?php /**PATH C:\Users\fajar\Downloads\shibaazaki\vendor\resources\views/components/heading1.blade.php ENDPATH**/ ?>