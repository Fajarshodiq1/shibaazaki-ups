<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['href' => '#']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['href' => '#']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<a href="<?php echo e($href); ?>"
    <?php echo e($attributes->merge(['class' => '"px-4 sm:px-6 lg:px-8 py-2.5 sm:py-3 lg:py-4 border-2 border-gray-600 rounded-full transition-all duration-300 flex items-center justify-center gap-2 text-sm sm:text-base lg:text-lg font-medium hover:border-blue-500 hover:text-blue-500 hover:shadow-md transform hover:-translate-y-0.5 w-full sm:w-fit'])); ?>>
    <?php echo e($slot); ?>

</a>
<?php /**PATH C:\Users\fajar\Downloads\shibaazaki\vendor\resources\views/components/front-button-seccondary.blade.php ENDPATH**/ ?>