

<?php $__env->startSection('title', 'Rental ' . $product->name); ?>

<?php $__env->startSection('content'); ?>
    <div class="min-h-screen bg-black text-white">
        <!-- Breadcrumb -->
        <section class="container max-w-[1230px] mx-auto pt-20 px-4 sm:px-6 lg:px-8">
            <nav class="flex mb-8" aria-label="Breadcrumb">
                <ol class="inline-flex items-center space-x-1 md:space-x-3">
                    <li class="inline-flex items-center">
                        <a href="/" class="text-gray-400 hover:text-white">Home</a>
                    </li>
                    <li>
                        <div class="flex items-center">
                            <span class="text-gray-600">/</span>
                            <a href="<?php echo e(route('rental.index')); ?>"
                                class="ml-1 text-gray-400 hover:text-white md:ml-2">Rental</a>
                        </div>
                    </li>
                    <li aria-current="page">
                        <div class="flex items-center">
                            <span class="text-gray-600">/</span>
                            <span class="ml-1 text-white md:ml-2"><?php echo e($product->name); ?></span>
                        </div>
                    </li>
                </ol>
            </nav>
        </section>

        <!-- Product Detail -->
        <section class="container max-w-[1230px] mx-auto mb-16 px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-12">
                <!-- Product Image -->
                <div class="lg:sticky lg:top-24 h-fit self-start">
                    <div class="aspect-square bg-[#181818] rounded-2xl overflow-hidden border border-gray-800">
                        <img src="<?php echo e($product->image ? asset('storage/' . $product->image) : 'https://via.placeholder.com/600x600?text=UPS'); ?>"
                            class="w-full h-full object-cover" alt="<?php echo e($product->name); ?>">
                    </div>
                </div>
                <!-- Product Info -->
                <div class="space-y-6">
                    <!-- Title & Brand -->
                    <div>
                        <div class="flex items-center gap-2 mb-2">
                            <span class="bg-blue-600 text-white px-3 py-1 rounded-full text-sm font-semibold">Rental
                                Available</span>
                            <span class="bg-gray-700 text-gray-300 px-3 py-1 rounded-full text-sm">
                                <?php echo e($product->category->name ?? 'UPS'); ?>

                            </span>
                        </div>
                        <h1 class="text-3xl md:text-4xl font-bold text-white mb-2"><?php echo e($product->name); ?></h1>
                        <p class="text-gray-400 text-lg">Brand: <?php echo e($product->brand); ?></p>
                    </div>

                    <!-- Specifications -->
                    <div class="bg-[#181818] rounded-2xl p-6 border border-gray-800">
                        <h3 class="text-xl font-semibold text-white mb-4">Spesifikasi</h3>
                        <div class="space-y-3">
                            <?php if($product->capacity): ?>
                                <div class="flex justify-between">
                                    <span class="text-gray-400">Kapasitas</span>
                                    <span class="text-white font-medium"><?php echo e($product->capacity); ?></span>
                                </div>
                            <?php endif; ?>
                            <div class="flex justify-between">
                                <span class="text-gray-400">Stok Tersedia</span>
                                <span class="text-white font-medium"><?php echo e($product->stock); ?> unit</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-gray-400">Kategori</span>
                                <span class="text-white font-medium"><?php echo e($product->category->name ?? 'UPS'); ?></span>
                            </div>
                        </div>
                    </div>

                    <!-- Description -->
                    <?php if($product->description): ?>
                        <div class="bg-[#181818] rounded-2xl p-6 border border-gray-800">
                            <h3 class="text-xl font-semibold text-white mb-4">Deskripsi</h3>
                            <div class="text-gray-300 leading-relaxed prose"><?php echo $product->description; ?></div>
                        </div>
                    <?php endif; ?>

                    <!-- Purchase Option -->
                    <?php if($product->price): ?>
                        <div class="bg-[#181818] rounded-2xl p-6 border border-gray-800">
                            <h3 class="text-xl font-semibold text-white mb-3">Harga Beli</h3>
                            <div class="flex items-center justify-between">
                                <span class="text-2xl font-bold text-green-400"><?php echo e($product->formatted_price); ?></span>
                                <button
                                    class="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-6 rounded-lg transition-colors duration-200">
                                    Beli Sekarang
                                </button>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </section>


        <!-- Rental Prices -->
        <section class="container max-w-[1230px] mx-auto mb-16 px-4 sm:px-6 lg:px-8">
            <div class="bg-[#181818] rounded-2xl p-8 border border-gray-800">
                <h2 class="text-2xl font-bold text-white mb-6">Paket Rental UPS 💰</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <?php $__currentLoopData = $product->rentalPrices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div
                            class="bg-black rounded-xl p-6 border border-gray-700 hover:border-blue-500 transition-all duration-300 hover:transform hover:scale-105">
                            <div class="text-center">
                                <h3 class="text-lg font-semibold text-white mb-2 capitalize"><?php echo e($rental->duration); ?></h3>
                                <div class="text-3xl font-bold text-blue-400 mb-4"><?php echo e($rental->formatted_price); ?></div>
                                <div class="text-gray-400 text-sm mb-4">
                                    <?php switch($rental->duration):
                                        case ('daily'): ?>
                                            Per Hari
                                        <?php break; ?>

                                        <?php case ('weekly'): ?>
                                            Per Minggu
                                        <?php break; ?>

                                        <?php case ('monthly'): ?>
                                            Per Bulan
                                        <?php break; ?>

                                        <?php case ('yearly'): ?>
                                            Per Tahun
                                        <?php break; ?>
                                    <?php endswitch; ?>
                                </div>
                                <button
                                    class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2 px-4 rounded-lg transition-colors duration-200">
                                    Pilih Paket
                                </button>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Contact Info -->
                <div class="mt-8 pt-8 border-t border-gray-700 text-center">
                    <h3 class="text-lg font-semibold text-white mb-3">Butuh Konsultasi?</h3>
                    <p class="text-gray-400 mb-4">Hubungi tim kami untuk mendapatkan penawaran terbaik sesuai kebutuhan Anda
                    </p>
                    <div class="flex flex-col sm:flex-row gap-4 justify-center">
                        <button
                            class="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-6 rounded-lg transition-colors duration-200">
                            WhatsApp
                        </button>
                        <button
                            class="bg-gray-700 hover:bg-gray-600 text-white font-semibold py-2 px-6 rounded-lg transition-colors duration-200">
                            Email
                        </button>
                    </div>
                </div>
            </div>
        </section>

        <!-- Similar Products -->
        <?php if($similarProducts->count() > 0): ?>
            <section class="container max-w-[1230px] mx-auto mb-20 px-4 sm:px-6 lg:px-8">
                <h2 class="text-2xl font-bold text-white mb-8">Produk UPS Lainnya</h2>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                    <?php $__currentLoopData = $similarProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $similarProduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div
                            class="rental-card flex flex-col rounded-2xl bg-[#181818] overflow-hidden hover:transform hover:scale-105 transition-all duration-300 border border-gray-800 hover:border-gray-600">
                            <a href="<?php echo e(route('rental.show', $similarProduct->slug)); ?>"
                                class="thumbnail w-full h-48 flex shrink-0 overflow-hidden relative">
                                <img src="<?php echo e($similarProduct->image ? asset('storage/' . $similarProduct->image) : 'https://via.placeholder.com/300x200?text=UPS'); ?>"
                                    class="w-full h-full object-cover" alt="<?php echo e($similarProduct->name); ?>" />
                            </a>
                            <div class="p-4 h-full flex flex-col justify-between">
                                <div>
                                    <a href="<?php echo e(route('rental.show', $similarProduct->slug)); ?>"
                                        class="font-semibold text-lg text-white hover:text-blue-400 transition-colors line-clamp-2 block mb-2">
                                        <?php echo e($similarProduct->name); ?>

                                    </a>
                                    <p class="text-gray-400 text-sm mb-3"><?php echo e($similarProduct->brand); ?></p>
                                    <?php if($similarProduct->cheapestRentalPrice): ?>
                                        <div class="text-blue-400 font-medium">
                                            Mulai <?php echo e($similarProduct->cheapestRentalPrice->formatted_price); ?>

                                        </div>
                                    <?php endif; ?>
                                </div>
                                <a href="<?php echo e(route('rental.show', $similarProduct->slug)); ?>"
                                    class="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg text-center block transition-colors duration-200 mt-3">
                                    Lihat Detail
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
        <?php endif; ?>
    </div>

    <style>
        .line-clamp-2 {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .rental-card:hover .thumbnail img {
            transform: scale(1.05);
            transition: transform 0.3s ease;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\CODING\shibaazaki-website\resources\views/front/rental/show.blade.php ENDPATH**/ ?>