<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => 'Tidak ada data',
    'message' => 'Data akan muncul di sini.',
    'icon' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => 'Tidak ada data',
    'message' => 'Data akan muncul di sini.',
    'icon' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="col-span-full text-center py-12">
    <div class="w-16 h-16 mx-auto mb-4 bg-belibang-dark-grey rounded-full flex items-center justify-center">
        <?php if($icon): ?>
            <?php echo $icon; ?>

        <?php else: ?>
            <!-- default icon -->
            <svg class="w-8 h-8 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
        <?php endif; ?>
    </div>
    <h3 class="text-lg font-medium text-white mb-2"><?php echo e($title); ?></h3>
    <p class="text-gray-400"><?php echo e($message); ?></p>
</div>
<?php /**PATH C:\Users\fajar\Downloads\shibaazaki\vendor\resources\views/components/empty-state.blade.php ENDPATH**/ ?>