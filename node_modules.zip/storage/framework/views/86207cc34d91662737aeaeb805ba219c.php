<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['name', 'id', 'defaultValue']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['name', 'id', 'defaultValue']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<div <?php echo e($attributes->merge(['class' => ''])); ?>>
    <div class="mb-10" id="<?php echo e($id); ?>"></div>
    <input type="hidden" name="<?php echo e($name); ?>" id="quill-editor-area-<?php echo e($name); ?>"
        value="<?php echo $defaultValue; ?>" />

    <?php $__env->startPush('scripts'); ?>
        <script defer>
            document.addEventListener('DOMContentLoaded', () => {
                if (document.getElementById('<?php echo e($id); ?>')) {
                    const editor = new Quill('#<?php echo e($id); ?>', {
                        theme: 'snow'
                    });
                    const quillEditor = document.getElementById('quill-editor-area-<?php echo e($name); ?>');

                    // Set default value if it's not empty
                    const defaultValue = quillEditor.value.trim();
                    if (defaultValue) {
                        editor.clipboard.dangerouslyPasteHTML(defaultValue);
                    }

                    // Sync Quill with the hidden input
                    editor.on('text-change', function() {
                        quillEditor.value = editor.root.innerHTML;
                    });

                    quillEditor.addEventListener('input', function() {
                        editor.root.innerHTML = quillEditor.value;
                    });
                }
            });
        </script>
    <?php $__env->stopPush(); ?>
</div>
<?php /**PATH C:\CODING\shibaazaki-website\resources\views/components/quil-editor.blade.php ENDPATH**/ ?>