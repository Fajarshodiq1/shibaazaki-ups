

<?php $__env->startSection('title', 'Rental Price UPS'); ?>

<?php $__env->startSection('content'); ?>
    <header
        class="w-full pt-20 pb-8 sm:pt-24 sm:pb-12 bg-[url('https://images.pexels.com/photos/8071904/pexels-photo-8071904.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1')] bg-cover bg-no-repeat bg-center relative z-0">
        <div class="container max-w-[1130px] mx-auto flex flex-col items-center justify-center gap-6 sm:gap-8 z-10">

            <!-- Judul -->
            <div class="flex flex-col gap-2 text-center w-fit mt-10 sm:mt-20 z-10">
                <h1 class="font-semibold text-3xl sm:text-4xl md:text-5xl lg:text-[60px] leading-snug sm:leading-[120%]">
                    Rental UPS</h1>
                <p class="text-gray-400 text-sm lg:text-lg max-w-2xl mx-auto">
                    Temukan harga sewa UPS terbaik untuk kebutuhan bisnis Anda dengan berbagai pilihan durasi rental
                </p>
            </div>
            <div class="w-full h-full absolute top-0 bg-gradient-to-b from-belibang-black/70 to-belibang-black z-0"></div>
    </header>

    <div class="max-w-screen-xl mx-auto p-5 sm:p-10 md:p-16">
        <!-- Header Section -->
        <section class="container max-w-[1230px] mx-auto pb-12 px-4 sm:px-6 lg:px-8">
            <!-- Search and Filter Section -->
            <div class="bg-[#181818] rounded-3xl  p-6 mb-8">
                <form method="GET" action="<?php echo e(route('rental.index')); ?>" class="grid grid-cols-1 md:grid-cols-4 gap-4">
                    <!-- Search Input -->
                    <div class="relative">
                        <input type="text" name="search" value="<?php echo e($searchTerm ?? ''); ?>"
                            placeholder="Cari produk UPS..."
                            class="w-full px-4 py-3 bg-black border border-gray-700 rounded-full text-white placeholder-gray-400 focus:border-blue-500 focus:outline-none">
                    </div>

                    <!-- Category Filter -->
                    <select name="category"
                        class="px-4 py-3 bg-black border border-gray-700 rounded-full text-white focus:border-blue-500 focus:outline-none">
                        <option value="">Semua Kategori</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->slug); ?>"
                                <?php echo e(($selectedCategory ?? '') == $category->slug ? 'selected' : ''); ?>>
                                <?php echo e($category->name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <!-- Duration Filter -->
                    <select name="duration"
                        class="px-4 py-3 bg-black border border-gray-700 rounded-full text-white focus:border-blue-500 focus:outline-none">
                        <option value="">Semua Durasi</option>
                        <?php $__currentLoopData = $durations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $duration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php echo e(($selectedDuration ?? '') == $key ? 'selected' : ''); ?>>
                                <?php echo e($duration); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <!-- Search Button -->
                    <button type="submit"
                        class="bg-img-purple-to-orange text-white font-semibold py-3 rounded-full transition-colors duration-200">
                        Cari
                    </button>
                </form>
            </div>
        </section>

        <!-- Products Section -->
        <section class="container max-w-[1230px] mx-auto mb-20 px-4 sm:px-6 lg:px-8">
            <?php if($products->count() > 0): ?>
                <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div
                            class="rental-card flex flex-col rounded-3xl bg-[#181818] overflow-hidden hover:transform hover:scale-105 transition-all duration-300 border border-gray-800 hover:border-gray-600">
                            <!-- Product Image -->
                            <a href="<?php echo e(route('rental.show', $product->slug)); ?>"
                                class="thumbnail w-full h-48 flex shrink-0 overflow-hidden relative">
                                <img src="<?php echo e($product->image ? asset('storage/' . $product->image) : 'https://via.placeholder.com/300x200?text=UPS'); ?>"
                                    class="w-full h-full object-cover" alt="<?php echo e($product->name); ?>" />
                            </a>

                            <!-- Product Info -->
                            <div class="p-4 h-full flex flex-col justify-between">
                                <div class="flex flex-col gap-3">
                                    <!-- Product Name & Brand -->
                                    <div>
                                        <a href="<?php echo e(route('rental.show', $product->slug)); ?>"
                                            class="font-bold text-lg text-white hover:text-blue-400 transition-colors line-clamp-2">
                                            <?php echo e($product->name); ?>

                                        </a>
                                        <p class="text-gray-400 text-sm"><?php echo e($product->brand); ?></p>
                                    </div>

                                    <!-- Capacity -->
                                    <?php if($product->capacity): ?>
                                        <div class="flex items-center gap-2">
                                            <span class="bg-gray-700 text-gray-300 px-2 py-1 rounded text-xs">
                                                <?php echo e($product->capacity); ?>

                                            </span>
                                        </div>
                                    <?php endif; ?>

                                    <!-- Rental Prices -->
                                    <div class="space-y-2">
                                        <?php $__currentLoopData = $product->rentalPrices->take(3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="flex justify-between items-center">
                                                <span
                                                    class="text-gray-400 text-sm capitalize"><?php echo e($rental->duration); ?></span>
                                                <span
                                                    class="text-white font-semibold"><?php echo e($rental->formatted_price); ?></span>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                        <?php if($product->rentalPrices->count() > 3): ?>
                                            <p class="text-blue-400 text-xs">+<?php echo e($product->rentalPrices->count() - 3); ?>

                                                more options</p>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <!-- Action Button -->
                                <div class="mt-4 pt-4 border-t border-gray-700">
                                    <a href="<?php echo e(route('rental.show', $product->slug)); ?>"
                                        class="w-full bg-img-purple-to-orange text-white font-semibold py-2 px-4 rounded-full text-center block transition-colors duration-200">
                                        Lihat Detail Rental
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Pagination -->
                <div class="mt-12 flex justify-center">
                    <?php echo e($products->links('pagination::tailwind')); ?>

                </div>
            <?php else: ?>
                <!-- Empty State -->
                <div class="text-center py-16">
                    <div class="max-w-md mx-auto">
                        <div class="text-gray-500 mb-4">
                            <svg class="w-16 h-16 mx-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z">
                                </path>
                            </svg>
                        </div>
                        <h3 class="text-xl font-semibold text-gray-400 mb-2">Tidak ada produk rental ditemukan</h3>
                        <p class="text-gray-500 mb-7">Coba ubah filter pencarian Anda atau hapus beberapa filter</p>
                        <a href="<?php echo e(route('rental.index')); ?>"
                            class="bg-img-purple-to-orange text-white font-semibold py-3 px-5 rounded-full transition-colors duration-200">
                            Reset Filter
                        </a>
                    </div>
                </div>
            <?php endif; ?>
        </section>
    </div>

    <style>
        .line-clamp-2 {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }

        .rental-card:hover .thumbnail img {
            transform: scale(1.05);
            transition: transform 0.3s ease;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\CODING\shibaazaki-website\resources\views/front/rental/index.blade.php ENDPATH**/ ?>