<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'action',
    'method' => 'POST',
    'title' => null,
    'subtitle' => null,
    'enctype' => null,
    'id' => 'defaultForm',
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'action',
    'method' => 'POST',
    'title' => null,
    'subtitle' => null,
    'enctype' => null,
    'id' => 'defaultForm',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>

<div class="bg-white shadow-lg rounded-lg overflow-hidden">
    <?php if($title || $subtitle): ?>
        <div class="bg-gradient-to-r from-blue-600 to-blue-700 px-6 py-4">
            <?php if($title): ?>
                <h2 class="text-xl font-semibold text-white"><?php echo e($title); ?></h2>
            <?php endif; ?>
            <?php if($subtitle): ?>
                <p class="text-blue-100 mt-1"><?php echo e($subtitle); ?></p>
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <div class="p-6">
        <form action="<?php echo e($action); ?>" method="<?php echo e($method === 'GET' ? 'GET' : 'POST'); ?>" id="<?php echo e($id); ?>"
            <?php if($enctype): ?> enctype="<?php echo e($enctype); ?>" <?php endif; ?>
            <?php echo e($attributes->merge(['class' => 'space-y-6'])); ?>>
            <?php if($method !== 'GET' && $method !== 'POST'): ?>
                <?php echo method_field($method); ?>
            <?php endif; ?>

            <?php if($method !== 'GET'): ?>
                <?php echo csrf_field(); ?>
            <?php endif; ?>

            <!-- Form Content -->
            <div class="space-y-4">
                <?php echo e($slot); ?>

            </div>

            <!-- Action Buttons -->
            <?php if(isset($actions)): ?>
                <div class="flex items-center justify-end space-x-3 pt-6 border-t border-gray-200">
                    <?php echo e($actions); ?>

                </div>
            <?php endif; ?>
        </form>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('<?php echo e($id); ?>');

            // Image preview functionality
            window.previewImage = function(input, previewId = 'imagePreview', uploadAreaId = 'uploadArea') {
                const file = input.files[0];
                const preview = document.getElementById(previewId);
                const uploadArea = document.getElementById(uploadAreaId);

                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        if (preview) {
                            preview.src = e.target.result;
                            preview.classList.remove('hidden');
                        }
                        if (uploadArea) {
                            uploadArea.classList.add('hidden');
                        }
                    }
                    reader.readAsDataURL(file);
                } else {
                    if (preview) {
                        preview.classList.add('hidden');
                    }
                    if (uploadArea) {
                        uploadArea.classList.remove('hidden');
                    }
                }
            };

            // Character counter for textareas
            const textareas = form.querySelectorAll('textarea[data-max-length]');
            textareas.forEach(function(textarea) {
                const maxLength = parseInt(textarea.dataset.maxLength);
                const counterId = textarea.dataset.counter || textarea.id + 'Count';
                let counter = document.getElementById(counterId);

                if (!counter) {
                    counter = document.createElement('div');
                    counter.id = counterId;
                    counter.className = 'text-sm text-gray-500 mt-1';
                    textarea.parentNode.appendChild(counter);
                }

                function updateCounter() {
                    const current = textarea.value.length;
                    counter.textContent = current + '/' + maxLength + ' characters';

                    if (current > maxLength * 0.9) {
                        counter.classList.add('text-red-500');
                        counter.classList.remove('text-gray-500');
                    } else {
                        counter.classList.remove('text-red-500');
                        counter.classList.add('text-gray-500');
                    }
                }

                textarea.addEventListener('input', updateCounter);
                updateCounter();
            });

            // Status toggle functionality
            window.updateStatusText = function(checkbox, statusTextId = 'statusText') {
                const statusText = document.getElementById(statusTextId);
                if (statusText) {
                    statusText.textContent = checkbox.checked ? 'Active' : 'Inactive';
                    statusText.className = checkbox.checked ? 'text-sm text-green-600 font-medium' :
                        'text-sm text-gray-600';
                }
            };

            // Auto-resize textareas
            const autoResizeTextareas = form.querySelectorAll('textarea[data-auto-resize]');
            autoResizeTextareas.forEach(function(textarea) {
                textarea.addEventListener('input', function() {
                    this.style.height = 'auto';
                    const maxHeight = parseInt(this.dataset.maxHeight) || 200;
                    this.style.height = Math.min(this.scrollHeight, maxHeight) + 'px';
                });
            });

            // Enhanced form validation
            if (form) {
                form.addEventListener('submit', function(e) {
                    let hasError = false;

                    // Clear previous error states
                    const errorElements = form.querySelectorAll('.validation-error');
                    errorElements.forEach(el => el.remove());

                    const inputs = form.querySelectorAll(
                        'input[required], textarea[required], select[required]');
                    inputs.forEach(function(input) {
                        input.classList.remove('border-red-500');

                        if (!input.value.trim()) {
                            hasError = true;
                            input.classList.add('border-red-500');
                            input.focus();

                            const errorDiv = document.createElement('div');
                            errorDiv.className = 'validation-error text-red-500 text-sm mt-1';
                            errorDiv.textContent = input.dataset.errorMessage || (input.name.charAt(
                                0).toUpperCase() + input.name.slice(1) + ' is required');
                            input.parentNode.appendChild(errorDiv);

                            setTimeout(() => {
                                errorDiv.remove();
                                input.classList.remove('border-red-500');
                            }, 5000);

                            return false;
                        }
                    });

                    if (hasError) {
                        e.preventDefault();
                    }
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH C:\CODING\shibaazaki-website\resources\views/components/form-card.blade.php ENDPATH**/ ?>